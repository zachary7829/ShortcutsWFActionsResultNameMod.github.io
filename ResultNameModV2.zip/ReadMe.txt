The Shortcuts Result Name Mod
Version 2
by zachary7829
(For iOS 12 Shortcuts 2.2.2)
For Installation, replace WFActions.plist in the Frameworks folder for Shortcuts.app with this WFActions.plist. Just in case, backup your current WFActions.plist if you want to go back. If you ever loose your original WFActions.plist, you can get the original file by using WFActions Backup.plist as your file. (Note: You’ll need to rename it to just WFActions.plist) 

Please, don’t use this on iOS 13.